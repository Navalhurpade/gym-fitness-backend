#!/bin/sh

rm -f encryptfile.bork
rm -f encryptfile
