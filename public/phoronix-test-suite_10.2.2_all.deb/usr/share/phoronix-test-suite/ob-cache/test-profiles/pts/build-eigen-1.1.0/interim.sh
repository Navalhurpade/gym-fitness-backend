#!/bin/sh

rm -rf eigen-3.3.9
tar -xf eigen-3.3.9.tar.bz2
