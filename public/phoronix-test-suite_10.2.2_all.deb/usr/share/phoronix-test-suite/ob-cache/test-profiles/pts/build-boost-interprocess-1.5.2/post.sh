#!/bin/sh

rm -rf boost_1_59_0
