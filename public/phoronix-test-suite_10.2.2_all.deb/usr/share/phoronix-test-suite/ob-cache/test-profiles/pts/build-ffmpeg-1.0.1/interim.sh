#!/bin/sh

cd ffmpeg-4.2.2
make clean
